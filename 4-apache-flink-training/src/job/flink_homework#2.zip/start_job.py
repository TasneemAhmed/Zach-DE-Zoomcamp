"""
Script Overview
This script (start_job.py) sets up and runs an Apache Flink streaming job using PyFlink. 
It reads web traffic events from a Kafka topic, enriches each event with geolocation data based on the
 IP address, and writes the processed events to both a Kafka topic and a PostgreSQL database.

Main Components:
- Kafka Source Table: Reads raw web traffic events from a Kafka topic.
- Geolocation UDF: Uses the IP2Location API to enrich events with country, state, and city information based on the IP address.
- Kafka Sink Table: Writes processed events back to another Kafka topic.
- Postgres Sink Table: Writes processed events to a PostgreSQL table.
- Flink Job Execution: The job is started in the log_processing() function, which sets up the environment, registers the UDF, creates the tables, and executes the data pipeline.
Environment Variables Required:
- KAFKA_URL: Kafka bootstrap servers
- KAFKA_TOPIC: Kafka source topic name
- KAFKA_GROUP: Kafka consumer group ID
- KAFKA_WEB_TRAFFIC_KEY: Kafka SASL username
- KAFKA_WEB_TRAFFIC_SECRET: Kafka SASL password
- POSTGRES_URL: JDBC URL for PostgreSQL
- POSTGRES_USER: PostgreSQL username
- POSTGRES_PASSWORD: PostgreSQL password
- IP_CODING_KEY: API key for IP2Location
How to run this script:
    make sure to have these files in the same directory:
    Dockerfile, docker-compose.yml, flink-env.env, requirements.txt, makefile
    The commands to run the script are:
        1. make down
        2. make up
        3. make job

"""

from pyflink.datastream import StreamExecutionEnvironment
from pyflink.table.udf import ScalarFunction, udf
import os
import json
import requests
from pyflink.table import EnvironmentSettings, DataTypes, TableEnvironment, StreamTableEnvironment

def create_processed_events_sink_kafka(t_env):
    """
    Creates a Kafka sink table in Flink for processed events.

    Args:
        t_env (StreamTableEnvironment): The Flink table environment.

    Returns:
        str: The name of the created Kafka sink table.
    """
    table_name = "process_events_kafka"
    kafka_key = os.environ.get("KAFKA_WEB_TRAFFIC_KEY", "")
    kafka_secret = os.environ.get("KAFKA_WEB_TRAFFIC_SECRET", "")
    sasl_config = f'org.apache.flink.kafka.shaded.org.apache.kafka.common.security.plain.PlainLoginModule required username="{kafka_key}" password="{kafka_secret}";'
    sink_ddl = f"""
        CREATE TABLE {table_name} (
            ip VARCHAR,
            event_timestamp VARCHAR,
            referrer VARCHAR,
            host VARCHAR,
            url VARCHAR,
            geodata VARCHAR
        ) WITH (
            'connector' = 'kafka',
            'properties.bootstrap.servers' = '{os.environ.get('KAFKA_URL')}',
            'topic' = '{os.environ.get('KAFKA_GROUP').split('.')[0] + '.' + table_name}',
            'properties.ssl.endpoint.identification.algorithm' = '',
            'properties.group.id' = '{os.environ.get('KAFKA_GROUP')}',
            'properties.security.protocol' = 'SASL_SSL',
            'properties.sasl.mechanism' = 'PLAIN',
            'properties.sasl.jaas.config' = '{sasl_config}',
            'format' = 'json'
        );
        """
    print(sink_ddl)
    t_env.execute_sql(sink_ddl)
    return table_name

"""
- It doesn't actually physically create the table in Postgres unless Postgres 
supports that through the JDBC connector AND user has the required permissions.
- It maps a Flink table to a Postgres table.
"""
def create_processed_events_sink_postgres(t_env):
    """
    Creates a JDBC sink table in Flink for processed events mapped to a PostgreSQL table.

    Args:
        t_env (StreamTableEnvironment): The Flink table environment.

    Returns:
        str: The name of the created Postgres sink table.
    Note:
        This function assumes that the PostgreSQL table already exists. 
        If it does not, you need to create it manually or use a different approach to create it.
    """
    table_name = 'processed_events'
    sink_ddl = f"""
        CREATE TABLE {table_name} (
            ip VARCHAR,
            event_timestamp TIMESTAMP(3),
            referrer VARCHAR,
            host VARCHAR,
            url VARCHAR,
            geodata VARCHAR
        ) WITH (
            'connector' = 'jdbc',
            'url' = '{os.environ.get("POSTGRES_URL")}',
            'table-name' = '{table_name}',
            'username' = '{os.environ.get("POSTGRES_USER", "postgres")}',
            'password' = '{os.environ.get("POSTGRES_PASSWORD", "postgres")}',
            'driver' = 'org.postgresql.Driver'
        );
    """
    t_env.execute_sql(sink_ddl)
    return table_name

# ScalarFunction: takes one column or row and return one column or row
# This function retrieves the location data based on the IP address
class GetLocation(ScalarFunction):
  """
    ScalarFunction UDF to fetch geolocation data for a given IP address using the IP2Location API.

    Args:
        ip_address (str): The IP address to look up.

    Returns:
        str: JSON string containing country, state, and city information.
  """
  def eval(self, ip_address):
    url = "https://api.ip2location.io"
    try:
        response = requests.get(url, params={
            'ip': ip_address,
            'key': os.environ.get("IP_CODING_KEY")
        })
        if response.status_code != 200:
            print("API Key:", os.environ.get("IP_CODING_KEY"))
            print(f"Calling IP geolocation for: {ip_address}")
            # Return empty dict if request failed
            return json.dumps({})
        print("API Key:", os.environ.get("IP_CODING_KEY"))
        print(f"Calling IP geolocation for: {ip_address}")
        data = response.json()
        return json.dumps({
            'country': data.get('country_code', ''),
            'state': data.get('region_name', ''),
            'city': data.get('city_name', '')
        })
    except Exception as e:
        print(f"Error fetching location for {ip_address}: {e}")
        return json.dumps({})

get_location = udf(GetLocation(), result_type=DataTypes.STRING())


"""
            'connector' = 'kafka', # the connector to read from Kafka, it can be 'jdbc', 'filesystem', etc.
            'properties.bootstrap.servers' = '{os.environ.get('KAFKA_URL')}', # where the Kafka broker is running
            'topic' = '{os.environ.get('KAFKA_TOPIC')}', # the topic to read from(act as table), streaming events from the topic
            'properties.group.id' = '{os.environ.get('KAFKA_GROUP')}', #group it's a group of consumers that share the same offset
            'properties.security.protocol' = 'SASL_SSL',
            'properties.sasl.mechanism' = 'PLAIN',
            'properties.sasl.jaas.config' = 'org.apache.flink.kafka.shaded.org.apache.kafka.common.security.plain.PlainLoginModule required username=\"{kafka_key}\" password=\"{kafka_secret}\";',
            'scan.startup.mode' = 'latest-offset', # start reading from the last offset
            # this mandatory and checkpoint is optional, as can read from the latest checkpoint or latest offset
            'properties.auto.offset.reset' = 'latest', # if the job is restarted, it will read from the latest offset in the topic
            'format' = 'json' # the format of the data in the topic
"""
def create_events_source_kafka(t_env):
    """
    Creates a Kafka source table in Flink for raw web traffic events.

    Args:
        t_env (StreamTableEnvironment): The Flink table environment.

    Returns:
        str: The name of the created Kafka source table.
    """
    kafka_key = os.environ.get("KAFKA_WEB_TRAFFIC_KEY", "")
    kafka_secret = os.environ.get("KAFKA_WEB_TRAFFIC_SECRET", "")
    table_name = "events"
    pattern = "yyyy-MM-dd''T''HH:mm:ss.SSS''Z''" # ISO 8601 format which will be used to parse the event_time
    # events table : It exists only in the Flink job's runtime memory as a streaming table view over the Kafka topic.
    source_ddl = f"""
        CREATE TABLE {table_name} (
            url VARCHAR,
            referrer VARCHAR,
            user_agent VARCHAR,
            host VARCHAR,
            ip VARCHAR,
            headers VARCHAR,
            event_time VARCHAR,
            event_timestamp AS TO_TIMESTAMP(event_time, '{pattern}'),
            WATERMARK FOR event_timestamp AS event_timestamp - INTERVAL '15' SECOND
        ) WITH (
            'connector' = 'kafka', 
            'properties.bootstrap.servers' = '{os.environ.get('KAFKA_URL')}', 
            'topic' = '{os.environ.get('KAFKA_TOPIC')}', 
            'properties.group.id' = '{os.environ.get('KAFKA_GROUP')}', 
            'properties.security.protocol' = 'SASL_SSL',
            'properties.sasl.mechanism' = 'PLAIN',
            'properties.sasl.jaas.config' = 'org.apache.flink.kafka.shaded.org.apache.kafka.common.security.plain.PlainLoginModule required username=\"{kafka_key}\" password=\"{kafka_secret}\";',
            'scan.startup.mode' = 'latest-offset', 
            'properties.auto.offset.reset' = 'latest', 
            'format' = 'json' 
        );
        """
    print(source_ddl)
    t_env.execute_sql(source_ddl)
    return table_name

def log_processing():
    """
    Main function to set up the Flink streaming job, register UDFs, create source/sink tables,
    and execute the data pipeline to process and enrich web traffic events.

    Steps:
        - Initializes Flink streaming and table environments.
        - Registers the geolocation UDF.
        - Creates Kafka source and sink tables, and Postgres sink table.
        - Executes SQL statements to process and write enriched events.
    """
    print('Starting Job!')
    # Set up the execution environment which is the entry point for any Flink application
    env = StreamExecutionEnvironment.get_execution_environment()
    print('got streaming environment')
    #automate checkpointing every 10 seconds
    env.enable_checkpointing(10 * 1000) 
     #every operator(in this script Source:process_events & process_events_kafka ) will run in 1 parallel instances
    env.set_parallelism(1)
    # Set up the table environment
    settings = EnvironmentSettings.new_instance().in_streaming_mode().build()
    t_env = StreamTableEnvironment.create(env, environment_settings=settings)
    # the below function is like UDF in Spark
    t_env.create_temporary_function("get_location", get_location)
    try:
        # Create Kafka table
        source_table = create_events_source_kafka(t_env)
        postgres_sink = create_processed_events_sink_postgres(t_env)
        kafka_sink = create_processed_events_sink_kafka(t_env)
        print('loading into kafka')
        t_env.execute_sql(
            f"""
                    INSERT INTO {kafka_sink}
                    SELECT
                        ip,
                        event_time,
                        referrer,
                        host,
                        url,
                        get_location(ip) as geodata
                    FROM {source_table}
                    """
        )
        print('loading into postgres')
        t_env.execute_sql(
            f"""
                    INSERT INTO {postgres_sink}
                    SELECT
                        ip,
                        event_timestamp,
                        referrer,
                        host,
                        url,
                        get_location(ip) as geodata
                    FROM {source_table}
                    """
        )
       
    except Exception as e:
        print("Writing records from Kafka to JDBC failed:", str(e))


if __name__ == '__main__':
    log_processing()
